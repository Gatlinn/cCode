﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Gatlinn_Homework_5
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void openToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                donutListBox.Items.Clear();                
                openFileDialog1.ShowDialog();
                StreamReader userFile;
                userFile = File.OpenText(openFileDialog1.FileName);                
                donutListBox.Visible = true;
                while (!userFile.EndOfStream)
                {
                    string duplicate = userFile.ReadLine();
                    if (donutListBox.Items.Contains(duplicate))
                    {}
                    else
                    {
                        donutListBox.Items.Add(userFile.ReadLine());
                    }
                }
                donutListBox.Sorted = true;
                userFile.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Something went wrong try something else", ex.Message);
            }
        }

        private void clearListToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DialogResult dlgResult;

            dlgResult = MessageBox.Show("Do you really want to clear the list?", "clear", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation);

            if (dlgResult == DialogResult.Yes)
                donutListBox.Items.Clear();
        }

        private void countDonutTypesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show(donutListBox.Items.Count.ToString());
        }

        private void removeDonutTypeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            donutListBox.Items.RemoveAt(donutListBox.SelectedIndex);
        }

        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AboutBox about = new AboutBox();
            about.Show();
        }

        private void addDonutTypeToolStripMenuItem_Click(object sender, EventArgs e)
        {           
            donutListBox.Items.Add(fileName.Text);
        }

        private void openAndAddToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                openFileDialog1.ShowDialog();
                StreamReader inputFile;
                inputFile = File.OpenText(openFileDialog1.FileName);
                donutListBox.Visible = true;
                while (!inputFile.EndOfStream)
                {
                    string duplicate = inputFile.ReadLine();
                    if (donutListBox.Items.Contains(duplicate))
                    { }
                    else
                    {
                        donutListBox.Items.Add(inputFile.ReadLine());
                    }
                }
                inputFile.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Something went wrong", ex.Message);
            }
        }

        private void saveFileToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {

                if (donutListBox.Text == null)
                {
                    MessageBox.Show("There is no data in the ListBox");
                }
                else
                {
                    SaveFileDialog saveFile = new SaveFileDialog();
                    if (saveFileDialog1.ShowDialog() == DialogResult.OK)

                    {

                        StreamWriter writer = new StreamWriter(saveFile.OpenFile());

                        for (int i = 0; i < donutListBox.Items.Count; i++)

                        {

                            writer.WriteLine(donutListBox.Items.ToString());

                        }

                        writer.Close();

                    }
                }
                if (donutListBox.Text != null)
                {
                    donutListBox.SelectedIndex = 0;
                }
                
            }
            catch (Exception ex)
            {
                MessageBox.Show("Try again", ex.Message);
            }
        }
    }
}
