﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Gatlin_Homework_4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            calculationsGB.Visible = true;
            if (int.Parse(hospitalStayTB.Text) >= 1)
            {}
            else
            {
                MessageBox.Show("Hospital stay less than 0");
                hospitalStayTB.Text = "";
                hospitalStayTB.Focus();
            }

            if (int.Parse(medicationTB.Text) >= 1)
            {}
            else if (medicationTB.Text.Contains("$"))
            {
                medicationTB.Text.TrimStart();
            }
            else if (medicationTB.Text == "")
            {
                MessageBox.Show("Please input medication charges");
            }
            else
            {
                MessageBox.Show("Hospital stay less than 0");
                hospitalStayTB.Text = "";
                hospitalStayTB.Focus();
            }

            if (surgicalTB.Text == "")
            {
                surgicalTB.Text = "0";
            }
            else if (surgicalTB.Text.Contains("$"))
            {
                surgicalTB.Text.TrimStart();
            }
            else if (int.Parse(surgicalTB.Text) < 0)
            {
                surgicalTB.Text = "0";
            }
            else
            {
                surgicalTB.Text = "0";
            }

            if (rehabTB.Text == "")
            {
                rehabTB.Text = "0";
            }
            else if (rehabTB.Text.Contains("$"))
            {
                rehabTB.Text.TrimStart();
            }
            else if (int.Parse(rehabTB.Text) < 0)
            {
                rehabTB.Text = "0";
            }
            if (labTB.Text == "")
            {
                MessageBox.Show("Please input a value for Lab fees");
            }
            else if (int.Parse(labTB.Text) <= 0)
            {
                MessageBox.Show("Please input a valid amount for Lab fees");
                labTB.Text = "";
                labTB.Focus();
            }

            try
            {
                int baseCharge = 0;
                if (int.Parse(hospitalStayTB.Text) > 0)
                {
                    baseCharge = 350 * int.Parse(hospitalStayTB.Text);
                    calcStayCharges.Text = baseCharge.ToString("c");
                }
                else
                {
                    MessageBox.Show("Hospital stay less than 0");
                    hospitalStayTB.Text = "";
                }
            double miscelaneousCharges = 0;
            double medication = 0;
            double surgical = 0;
            double lab = 0;
            double rehab = 0;
            double.TryParse(medicationTB.Text, out medication);
            double.TryParse(surgicalTB.Text, out surgical);
            double.TryParse(labTB.Text, out lab);
            double.TryParse(rehabTB.Text, out rehab);
              
            miscelaneousCharges = medication + surgical + lab + rehab;
            calcMiscCharges.Text = miscelaneousCharges.ToString("c");

            double total = miscelaneousCharges + baseCharge;
            calcTotalCharges.Text = total.ToString("c");

            double average = 0;
            average = total / double.Parse(hospitalStayTB.Text);
            averageLabel.Text = average.ToString("c");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message,"Catch-all: Please make sure all the inputs are correct");
            }

            if (nameTB.Text == "")
            {
                MessageBox.Show("Please input name");
            }

            if(emailTB.Text.Contains("@") && emailTB.Text.Contains(".") && emailTB.Text != null)
            {}
            else
            {
                MessageBox.Show("Please input valid email address");
            }

            if(phoneNumberTB.Text != "")
            {
                if(phoneNumberTB.Text.Contains(".") && phoneNumberTB.Text.Contains("."))
                {}
                else
                {
                    MessageBox.Show("Please input your phone number in format 000.000.0000");
                }
            }
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void resetButton_Click(object sender, EventArgs e)
        {
            nameTB.Text = "";
            emailTB.Text = "";
            phoneNumberTB.Text = "";
            hospitalStayTB.Text = "";
            medicationTB.Text = "";
            surgicalTB.Text = "";
            labTB.Text = "";
            rehabTB.Text = "";
            calculationsGB.Visible = false;
        }

        private void nameTB_TextChanged(object sender, EventArgs e)
        {
            this.Focus();
        }

        private void aboutButton_Click(object sender, EventArgs e)
        {
            AboutForm aboutSplashAndAbout = new AboutForm();      //Construct an instance of class AboutForm 
            aboutSplashAndAbout.ShowDialog();                     //Show as a modal dialog
        }
    }
}
