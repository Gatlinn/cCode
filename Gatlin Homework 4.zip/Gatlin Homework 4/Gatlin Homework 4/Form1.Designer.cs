﻿namespace Gatlin_Homework_4
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.hospitalStayTB = new System.Windows.Forms.TextBox();
            this.medicationTB = new System.Windows.Forms.TextBox();
            this.surgicalTB = new System.Windows.Forms.TextBox();
            this.labTB = new System.Windows.Forms.TextBox();
            this.rehabTB = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.calculationsGB = new System.Windows.Forms.GroupBox();
            this.averageLabel = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.calcTotalCharges = new System.Windows.Forms.Label();
            this.calcMiscCharges = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.calcStayCharges = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.exitButton = new System.Windows.Forms.Button();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.nameTB = new System.Windows.Forms.TextBox();
            this.emailTB = new System.Windows.Forms.TextBox();
            this.phoneNumberTB = new System.Windows.Forms.TextBox();
            this.resetButton = new System.Windows.Forms.Button();
            this.aboutButton = new System.Windows.Forms.Button();
            this.calculationsGB.SuspendLayout();
            this.SuspendLayout();
            // 
            // hospitalStayTB
            // 
            this.hospitalStayTB.Location = new System.Drawing.Point(185, 255);
            this.hospitalStayTB.Name = "hospitalStayTB";
            this.hospitalStayTB.Size = new System.Drawing.Size(100, 22);
            this.hospitalStayTB.TabIndex = 3;
            // 
            // medicationTB
            // 
            this.medicationTB.Location = new System.Drawing.Point(185, 300);
            this.medicationTB.Name = "medicationTB";
            this.medicationTB.Size = new System.Drawing.Size(100, 22);
            this.medicationTB.TabIndex = 4;
            // 
            // surgicalTB
            // 
            this.surgicalTB.Location = new System.Drawing.Point(185, 345);
            this.surgicalTB.Name = "surgicalTB";
            this.surgicalTB.Size = new System.Drawing.Size(100, 22);
            this.surgicalTB.TabIndex = 5;
            // 
            // labTB
            // 
            this.labTB.Location = new System.Drawing.Point(185, 390);
            this.labTB.Name = "labTB";
            this.labTB.Size = new System.Drawing.Size(100, 22);
            this.labTB.TabIndex = 6;
            // 
            // rehabTB
            // 
            this.rehabTB.Location = new System.Drawing.Point(185, 435);
            this.rehabTB.Name = "rehabTB";
            this.rehabTB.Size = new System.Drawing.Size(100, 22);
            this.rehabTB.TabIndex = 7;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(147, 235);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(177, 17);
            this.label1.TabIndex = 5;
            this.label1.Text = "Days spent in the Hospital:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(138, 280);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(203, 17);
            this.label2.TabIndex = 6;
            this.label2.Text = "Amount of medication charges:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(147, 325);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(184, 17);
            this.label3.TabIndex = 7;
            this.label3.Text = "Amount of surgical charges:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(169, 370);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(130, 17);
            this.label4.TabIndex = 8;
            this.label4.Text = "Amount of lab fees:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(105, 415);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(271, 17);
            this.label5.TabIndex = 9;
            this.label5.Text = "Amount of physical rehabilitation charges:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Bauhaus 93", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(101, 51);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(275, 32);
            this.label6.TabIndex = 10;
            this.label6.Text = "Hospital Calculator";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(107, 491);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(100, 43);
            this.button1.TabIndex = 8;
            this.button1.Text = "Calculate";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // calculationsGB
            // 
            this.calculationsGB.Controls.Add(this.averageLabel);
            this.calculationsGB.Controls.Add(this.label13);
            this.calculationsGB.Controls.Add(this.label9);
            this.calculationsGB.Controls.Add(this.calcTotalCharges);
            this.calculationsGB.Controls.Add(this.calcMiscCharges);
            this.calculationsGB.Controls.Add(this.label8);
            this.calculationsGB.Controls.Add(this.calcStayCharges);
            this.calculationsGB.Controls.Add(this.label7);
            this.calculationsGB.Location = new System.Drawing.Point(65, 571);
            this.calculationsGB.Name = "calculationsGB";
            this.calculationsGB.Size = new System.Drawing.Size(346, 183);
            this.calculationsGB.TabIndex = 12;
            this.calculationsGB.TabStop = false;
            this.calculationsGB.Text = "Calculations";
            this.calculationsGB.Visible = false;
            // 
            // averageLabel
            // 
            this.averageLabel.AutoSize = true;
            this.averageLabel.Location = new System.Drawing.Point(242, 139);
            this.averageLabel.Name = "averageLabel";
            this.averageLabel.Size = new System.Drawing.Size(44, 17);
            this.averageLabel.TabIndex = 16;
            this.averageLabel.Text = "$0.00";
            this.averageLabel.UseMnemonic = false;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(6, 139);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(122, 17);
            this.label13.TabIndex = 15;
            this.label13.Text = "Average Daily Bill:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(6, 98);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(44, 17);
            this.label9.TabIndex = 13;
            this.label9.Text = "Total:";
            // 
            // calcTotalCharges
            // 
            this.calcTotalCharges.AutoSize = true;
            this.calcTotalCharges.Location = new System.Drawing.Point(242, 98);
            this.calcTotalCharges.Name = "calcTotalCharges";
            this.calcTotalCharges.Size = new System.Drawing.Size(44, 17);
            this.calcTotalCharges.TabIndex = 14;
            this.calcTotalCharges.Text = "$0.00";
            // 
            // calcMiscCharges
            // 
            this.calcMiscCharges.AutoSize = true;
            this.calcMiscCharges.Location = new System.Drawing.Point(242, 56);
            this.calcMiscCharges.Name = "calcMiscCharges";
            this.calcMiscCharges.Size = new System.Drawing.Size(44, 17);
            this.calcMiscCharges.TabIndex = 3;
            this.calcMiscCharges.Text = "$0.00";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(6, 56);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(186, 34);
            this.label8.TabIndex = 2;
            this.label8.Text = "Medication, Surgical, \r\nLab, Physical Rehabilitation:";
            // 
            // calcStayCharges
            // 
            this.calcStayCharges.AutoSize = true;
            this.calcStayCharges.Location = new System.Drawing.Point(242, 18);
            this.calcStayCharges.Name = "calcStayCharges";
            this.calcStayCharges.Size = new System.Drawing.Size(44, 17);
            this.calcStayCharges.TabIndex = 1;
            this.calcStayCharges.Text = "$0.00";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(6, 18);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(94, 17);
            this.label7.TabIndex = 0;
            this.label7.Text = "Base Charge:";
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(372, 12);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 10;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(147, 190);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(179, 17);
            this.label10.TabIndex = 14;
            this.label10.Text = "Enter Your Phone Number:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(178, 96);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(121, 17);
            this.label11.TabIndex = 15;
            this.label11.Text = "Enter Your Name:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(178, 141);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(118, 17);
            this.label12.TabIndex = 16;
            this.label12.Text = "Enter Your Email:";
            // 
            // nameTB
            // 
            this.nameTB.Location = new System.Drawing.Point(185, 116);
            this.nameTB.Name = "nameTB";
            this.nameTB.Size = new System.Drawing.Size(100, 22);
            this.nameTB.TabIndex = 0;
            this.nameTB.TextChanged += new System.EventHandler(this.nameTB_TextChanged);
            // 
            // emailTB
            // 
            this.emailTB.Location = new System.Drawing.Point(185, 165);
            this.emailTB.Name = "emailTB";
            this.emailTB.Size = new System.Drawing.Size(100, 22);
            this.emailTB.TabIndex = 1;
            // 
            // phoneNumberTB
            // 
            this.phoneNumberTB.Location = new System.Drawing.Point(185, 210);
            this.phoneNumberTB.Name = "phoneNumberTB";
            this.phoneNumberTB.Size = new System.Drawing.Size(100, 22);
            this.phoneNumberTB.TabIndex = 2;
            // 
            // resetButton
            // 
            this.resetButton.Location = new System.Drawing.Point(251, 491);
            this.resetButton.Name = "resetButton";
            this.resetButton.Size = new System.Drawing.Size(100, 43);
            this.resetButton.TabIndex = 9;
            this.resetButton.Text = "Reset Input";
            this.resetButton.UseVisualStyleBackColor = true;
            this.resetButton.Click += new System.EventHandler(this.resetButton_Click);
            // 
            // aboutButton
            // 
            this.aboutButton.Location = new System.Drawing.Point(12, 12);
            this.aboutButton.Name = "aboutButton";
            this.aboutButton.Size = new System.Drawing.Size(75, 23);
            this.aboutButton.TabIndex = 11;
            this.aboutButton.Text = "About";
            this.aboutButton.UseVisualStyleBackColor = true;
            this.aboutButton.Click += new System.EventHandler(this.aboutButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(459, 828);
            this.Controls.Add(this.aboutButton);
            this.Controls.Add(this.resetButton);
            this.Controls.Add(this.phoneNumberTB);
            this.Controls.Add(this.emailTB);
            this.Controls.Add(this.nameTB);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.calculationsGB);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.rehabTB);
            this.Controls.Add(this.labTB);
            this.Controls.Add(this.surgicalTB);
            this.Controls.Add(this.medicationTB);
            this.Controls.Add(this.hospitalStayTB);
            this.Name = "Form1";
            this.Text = "Hospital Calculator";
            this.calculationsGB.ResumeLayout(false);
            this.calculationsGB.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox hospitalStayTB;
        private System.Windows.Forms.TextBox medicationTB;
        private System.Windows.Forms.TextBox surgicalTB;
        private System.Windows.Forms.TextBox labTB;
        private System.Windows.Forms.TextBox rehabTB;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.GroupBox calculationsGB;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label calcTotalCharges;
        private System.Windows.Forms.Label calcMiscCharges;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label calcStayCharges;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox nameTB;
        private System.Windows.Forms.TextBox emailTB;
        private System.Windows.Forms.TextBox phoneNumberTB;
        private System.Windows.Forms.Label averageLabel;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Button resetButton;
        private System.Windows.Forms.Button aboutButton;
    }
}

