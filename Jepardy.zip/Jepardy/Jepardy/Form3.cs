﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Jepardy
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();

        }

        private void c1_100_Click(object sender, EventArgs e)
        {
            c1_100.Enabled = false;
            var frm1 = new c1_100();
            frm1.Show();
        }
        
        private void Exit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void c6_300_Click(object sender, EventArgs e)
        {

        }

        private void Form3_Load(object sender, EventArgs e)
        {
            FormBorderStyle = FormBorderStyle.None;
            WindowState = FormWindowState.Maximized;
        }

        private void c1_200_Click(object sender, EventArgs e)
        {
            c1_200.Enabled = false;
            var frm2 = new DJc1_400();
            frm2.Show();
        }

        private void c1_300_Click(object sender, EventArgs e)
        {
            c1_300.Enabled = false;
            var frm3 = new DJc1_600();
            frm3.Show();
        }

        private void c1_400_Click(object sender, EventArgs e)
        {
            c1_400.Enabled = false;
            var frm4 = new DJc1_800();
            frm4.Show();
        }

        private void c1_500_Click(object sender, EventArgs e)
        {
            c1_500.Enabled = false;
            var frm5 = new DJc1_1000();
            frm5.Show();
        }

        private void c2_100_Click(object sender, EventArgs e)
        {
            c2_100.Enabled = false;
            var frm6 = new DJc2_200();
            frm6.Show();
        }

        private void c2_200_Click(object sender, EventArgs e)
        {
            c2_200.Enabled = false;
            var frm7 = new DJc2_400();
            frm7.Show();
        }

        private void c2_300_Click(object sender, EventArgs e)
        {
            c2_300.Enabled = false;
            var frm8 = new DJc2_600();
            frm8.Show();
        }

        private void c2_400_Click(object sender, EventArgs e)
        {
            c2_400.Enabled = false;
            var frm9 = new DJc2_800();
            frm9.Show();
        }

        private void c2_500_Click(object sender, EventArgs e)
        {
            c2_500.Enabled = false;
            var frm10 = new DJc2_1000();
            frm10.Show();
        }

        private void c3_100_Click(object sender, EventArgs e)
        {
            c3_100.Enabled = false;
            var frm11 = new DJc3_200();
            frm11.Show();
        }

        private void c3_200_Click(object sender, EventArgs e)
        {
            c3_200.Enabled = false;
            var frm12 = new DJc3_400();
            frm12.Show();
        }

        private void c3_300_Click(object sender, EventArgs e)
        {
            c3_300.Enabled = false;
            var frm13 = new DJc3_600();
            frm13.Show();
        }

        private void c3_400_Click(object sender, EventArgs e)
        {
            c3_400.Enabled = false;
            var frm14 = new DJc3_800();
            frm14.Show();
        }

        private void c3_500_Click(object sender, EventArgs e)
        {
            c3_500.Enabled = false;
            var frm15 = new DJc3_1000();
            frm15.Show();
        }
    }
}
