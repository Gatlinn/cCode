﻿namespace Jepardy
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form3));
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.numericUpDown3 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown2 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown1 = new System.Windows.Forms.NumericUpDown();
            this.doubleJeopardy = new System.Windows.Forms.Button();
            this.c6_500 = new System.Windows.Forms.Button();
            this.c5_500 = new System.Windows.Forms.Button();
            this.c4_500 = new System.Windows.Forms.Button();
            this.c3_500 = new System.Windows.Forms.Button();
            this.c2_500 = new System.Windows.Forms.Button();
            this.c1_500 = new System.Windows.Forms.Button();
            this.c6_400 = new System.Windows.Forms.Button();
            this.c5_400 = new System.Windows.Forms.Button();
            this.c4_400 = new System.Windows.Forms.Button();
            this.c3_400 = new System.Windows.Forms.Button();
            this.c2_400 = new System.Windows.Forms.Button();
            this.c1_400 = new System.Windows.Forms.Button();
            this.c6_300 = new System.Windows.Forms.Button();
            this.c5_300 = new System.Windows.Forms.Button();
            this.c4_300 = new System.Windows.Forms.Button();
            this.c3_300 = new System.Windows.Forms.Button();
            this.c2_300 = new System.Windows.Forms.Button();
            this.c1_300 = new System.Windows.Forms.Button();
            this.c6_200 = new System.Windows.Forms.Button();
            this.c5_200 = new System.Windows.Forms.Button();
            this.c4_200 = new System.Windows.Forms.Button();
            this.c3_200 = new System.Windows.Forms.Button();
            this.c2_200 = new System.Windows.Forms.Button();
            this.c1_200 = new System.Windows.Forms.Button();
            this.c2_100 = new System.Windows.Forms.Button();
            this.c6_100 = new System.Windows.Forms.Button();
            this.c5_100 = new System.Windows.Forms.Button();
            this.c4_100 = new System.Windows.Forms.Button();
            this.c3_100 = new System.Windows.Forms.Button();
            this.c1_100 = new System.Windows.Forms.Button();
            this.Exit = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).BeginInit();
            this.SuspendLayout();
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F);
            this.label9.ForeColor = System.Drawing.Color.Yellow;
            this.label9.Location = new System.Drawing.Point(1730, 183);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(139, 28);
            this.label9.TabIndex = 97;
            this.label9.Text = "Category 6";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F);
            this.label8.ForeColor = System.Drawing.Color.Yellow;
            this.label8.Location = new System.Drawing.Point(1410, 183);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(139, 28);
            this.label8.TabIndex = 96;
            this.label8.Text = "Category 5";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F);
            this.label7.ForeColor = System.Drawing.Color.Yellow;
            this.label7.Location = new System.Drawing.Point(1105, 183);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(139, 28);
            this.label7.TabIndex = 95;
            this.label7.Text = "Category 4";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F);
            this.label6.ForeColor = System.Drawing.Color.Yellow;
            this.label6.Location = new System.Drawing.Point(771, 183);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(139, 28);
            this.label6.TabIndex = 94;
            this.label6.Text = "Category 3";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F);
            this.label5.ForeColor = System.Drawing.Color.Yellow;
            this.label5.Location = new System.Drawing.Point(453, 183);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(139, 28);
            this.label5.TabIndex = 93;
            this.label5.Text = "Category 2";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F);
            this.label4.ForeColor = System.Drawing.Color.Yellow;
            this.label4.Location = new System.Drawing.Point(127, 183);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(139, 28);
            this.label4.TabIndex = 92;
            this.label4.Text = "Category 1";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label3.Location = new System.Drawing.Point(1268, 923);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(56, 17);
            this.label3.TabIndex = 91;
            this.label3.Text = "Team 3";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label2.Location = new System.Drawing.Point(735, 923);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(56, 17);
            this.label2.TabIndex = 90;
            this.label2.Text = "Team 2";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label1.Location = new System.Drawing.Point(197, 923);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(56, 17);
            this.label1.TabIndex = 89;
            this.label1.Text = "Team 1";
            // 
            // numericUpDown3
            // 
            this.numericUpDown3.Increment = new decimal(new int[] {
            200,
            0,
            0,
            0});
            this.numericUpDown3.Location = new System.Drawing.Point(1218, 962);
            this.numericUpDown3.Maximum = new decimal(new int[] {
            1569325056,
            23283064,
            0,
            0});
            this.numericUpDown3.Minimum = new decimal(new int[] {
            1215752192,
            23,
            0,
            -2147483648});
            this.numericUpDown3.Name = "numericUpDown3";
            this.numericUpDown3.Size = new System.Drawing.Size(172, 22);
            this.numericUpDown3.TabIndex = 88;
            // 
            // numericUpDown2
            // 
            this.numericUpDown2.Increment = new decimal(new int[] {
            200,
            0,
            0,
            0});
            this.numericUpDown2.Location = new System.Drawing.Point(687, 962);
            this.numericUpDown2.Maximum = new decimal(new int[] {
            -1486618624,
            232830643,
            0,
            0});
            this.numericUpDown2.Minimum = new decimal(new int[] {
            1316134912,
            2328,
            0,
            -2147483648});
            this.numericUpDown2.Name = "numericUpDown2";
            this.numericUpDown2.Size = new System.Drawing.Size(172, 22);
            this.numericUpDown2.TabIndex = 87;
            // 
            // numericUpDown1
            // 
            this.numericUpDown1.Increment = new decimal(new int[] {
            200,
            0,
            0,
            0});
            this.numericUpDown1.Location = new System.Drawing.Point(142, 962);
            this.numericUpDown1.Maximum = new decimal(new int[] {
            1316134912,
            2328,
            0,
            0});
            this.numericUpDown1.Minimum = new decimal(new int[] {
            -727379968,
            232,
            0,
            -2147483648});
            this.numericUpDown1.Name = "numericUpDown1";
            this.numericUpDown1.Size = new System.Drawing.Size(172, 22);
            this.numericUpDown1.TabIndex = 86;
            // 
            // doubleJeopardy
            // 
            this.doubleJeopardy.Location = new System.Drawing.Point(255, 26);
            this.doubleJeopardy.Name = "doubleJeopardy";
            this.doubleJeopardy.Size = new System.Drawing.Size(107, 43);
            this.doubleJeopardy.TabIndex = 85;
            this.doubleJeopardy.Text = "Double Jeopardy!";
            this.doubleJeopardy.UseVisualStyleBackColor = true;
            // 
            // c6_500
            // 
            this.c6_500.Location = new System.Drawing.Point(1692, 778);
            this.c6_500.Name = "c6_500";
            this.c6_500.Size = new System.Drawing.Size(219, 129);
            this.c6_500.TabIndex = 84;
            this.c6_500.Text = "$1000";
            this.c6_500.UseVisualStyleBackColor = true;
            // 
            // c5_500
            // 
            this.c5_500.Location = new System.Drawing.Point(1377, 778);
            this.c5_500.Name = "c5_500";
            this.c5_500.Size = new System.Drawing.Size(219, 129);
            this.c5_500.TabIndex = 83;
            this.c5_500.Text = "$1000";
            this.c5_500.UseVisualStyleBackColor = true;
            // 
            // c4_500
            // 
            this.c4_500.Location = new System.Drawing.Point(1060, 778);
            this.c4_500.Name = "c4_500";
            this.c4_500.Size = new System.Drawing.Size(219, 129);
            this.c4_500.TabIndex = 82;
            this.c4_500.Text = "$1000";
            this.c4_500.UseVisualStyleBackColor = true;
            // 
            // c3_500
            // 
            this.c3_500.Location = new System.Drawing.Point(750, 778);
            this.c3_500.Name = "c3_500";
            this.c3_500.Size = new System.Drawing.Size(219, 129);
            this.c3_500.TabIndex = 81;
            this.c3_500.Text = "$1000";
            this.c3_500.UseVisualStyleBackColor = true;
            this.c3_500.Click += new System.EventHandler(this.c3_500_Click);
            // 
            // c2_500
            // 
            this.c2_500.Location = new System.Drawing.Point(422, 778);
            this.c2_500.Name = "c2_500";
            this.c2_500.Size = new System.Drawing.Size(219, 129);
            this.c2_500.TabIndex = 80;
            this.c2_500.Text = "$1000";
            this.c2_500.UseVisualStyleBackColor = true;
            this.c2_500.Click += new System.EventHandler(this.c2_500_Click);
            // 
            // c1_500
            // 
            this.c1_500.Location = new System.Drawing.Point(95, 778);
            this.c1_500.Name = "c1_500";
            this.c1_500.Size = new System.Drawing.Size(219, 129);
            this.c1_500.TabIndex = 79;
            this.c1_500.Text = "$1000";
            this.c1_500.UseVisualStyleBackColor = true;
            this.c1_500.Click += new System.EventHandler(this.c1_500_Click);
            // 
            // c6_400
            // 
            this.c6_400.Location = new System.Drawing.Point(1692, 643);
            this.c6_400.Name = "c6_400";
            this.c6_400.Size = new System.Drawing.Size(219, 129);
            this.c6_400.TabIndex = 78;
            this.c6_400.Text = "$800";
            this.c6_400.UseVisualStyleBackColor = true;
            // 
            // c5_400
            // 
            this.c5_400.Location = new System.Drawing.Point(1377, 643);
            this.c5_400.Name = "c5_400";
            this.c5_400.Size = new System.Drawing.Size(219, 129);
            this.c5_400.TabIndex = 77;
            this.c5_400.Text = "$800";
            this.c5_400.UseVisualStyleBackColor = true;
            // 
            // c4_400
            // 
            this.c4_400.Location = new System.Drawing.Point(1060, 643);
            this.c4_400.Name = "c4_400";
            this.c4_400.Size = new System.Drawing.Size(219, 129);
            this.c4_400.TabIndex = 76;
            this.c4_400.Text = "$800";
            this.c4_400.UseVisualStyleBackColor = true;
            // 
            // c3_400
            // 
            this.c3_400.Location = new System.Drawing.Point(750, 643);
            this.c3_400.Name = "c3_400";
            this.c3_400.Size = new System.Drawing.Size(219, 129);
            this.c3_400.TabIndex = 75;
            this.c3_400.Text = "$800";
            this.c3_400.UseVisualStyleBackColor = true;
            this.c3_400.Click += new System.EventHandler(this.c3_400_Click);
            // 
            // c2_400
            // 
            this.c2_400.Location = new System.Drawing.Point(422, 643);
            this.c2_400.Name = "c2_400";
            this.c2_400.Size = new System.Drawing.Size(219, 129);
            this.c2_400.TabIndex = 74;
            this.c2_400.Text = "$800";
            this.c2_400.UseVisualStyleBackColor = true;
            this.c2_400.Click += new System.EventHandler(this.c2_400_Click);
            // 
            // c1_400
            // 
            this.c1_400.Location = new System.Drawing.Point(95, 643);
            this.c1_400.Name = "c1_400";
            this.c1_400.Size = new System.Drawing.Size(219, 129);
            this.c1_400.TabIndex = 73;
            this.c1_400.Text = "$800";
            this.c1_400.UseVisualStyleBackColor = true;
            this.c1_400.Click += new System.EventHandler(this.c1_400_Click);
            // 
            // c6_300
            // 
            this.c6_300.Location = new System.Drawing.Point(1692, 508);
            this.c6_300.Name = "c6_300";
            this.c6_300.Size = new System.Drawing.Size(219, 129);
            this.c6_300.TabIndex = 72;
            this.c6_300.Text = "$600";
            this.c6_300.UseVisualStyleBackColor = true;
            this.c6_300.Click += new System.EventHandler(this.c6_300_Click);
            // 
            // c5_300
            // 
            this.c5_300.Location = new System.Drawing.Point(1377, 508);
            this.c5_300.Name = "c5_300";
            this.c5_300.Size = new System.Drawing.Size(219, 129);
            this.c5_300.TabIndex = 71;
            this.c5_300.Text = "$600";
            this.c5_300.UseVisualStyleBackColor = true;
            // 
            // c4_300
            // 
            this.c4_300.Location = new System.Drawing.Point(1060, 508);
            this.c4_300.Name = "c4_300";
            this.c4_300.Size = new System.Drawing.Size(219, 129);
            this.c4_300.TabIndex = 70;
            this.c4_300.Text = "$600";
            this.c4_300.UseVisualStyleBackColor = true;
            // 
            // c3_300
            // 
            this.c3_300.Location = new System.Drawing.Point(750, 508);
            this.c3_300.Name = "c3_300";
            this.c3_300.Size = new System.Drawing.Size(219, 129);
            this.c3_300.TabIndex = 69;
            this.c3_300.Text = "$600";
            this.c3_300.UseVisualStyleBackColor = true;
            this.c3_300.Click += new System.EventHandler(this.c3_300_Click);
            // 
            // c2_300
            // 
            this.c2_300.Location = new System.Drawing.Point(422, 508);
            this.c2_300.Name = "c2_300";
            this.c2_300.Size = new System.Drawing.Size(219, 129);
            this.c2_300.TabIndex = 68;
            this.c2_300.Text = "$600";
            this.c2_300.UseVisualStyleBackColor = true;
            this.c2_300.Click += new System.EventHandler(this.c2_300_Click);
            // 
            // c1_300
            // 
            this.c1_300.Location = new System.Drawing.Point(95, 508);
            this.c1_300.Name = "c1_300";
            this.c1_300.Size = new System.Drawing.Size(219, 129);
            this.c1_300.TabIndex = 67;
            this.c1_300.Text = "$600";
            this.c1_300.UseVisualStyleBackColor = true;
            this.c1_300.Click += new System.EventHandler(this.c1_300_Click);
            // 
            // c6_200
            // 
            this.c6_200.Location = new System.Drawing.Point(1692, 373);
            this.c6_200.Name = "c6_200";
            this.c6_200.Size = new System.Drawing.Size(219, 129);
            this.c6_200.TabIndex = 66;
            this.c6_200.Text = "$400";
            this.c6_200.UseVisualStyleBackColor = true;
            // 
            // c5_200
            // 
            this.c5_200.Location = new System.Drawing.Point(1377, 373);
            this.c5_200.Name = "c5_200";
            this.c5_200.Size = new System.Drawing.Size(219, 129);
            this.c5_200.TabIndex = 65;
            this.c5_200.Text = "$400";
            this.c5_200.UseVisualStyleBackColor = true;
            // 
            // c4_200
            // 
            this.c4_200.Location = new System.Drawing.Point(1060, 373);
            this.c4_200.Name = "c4_200";
            this.c4_200.Size = new System.Drawing.Size(219, 129);
            this.c4_200.TabIndex = 64;
            this.c4_200.Text = "$400";
            this.c4_200.UseVisualStyleBackColor = true;
            // 
            // c3_200
            // 
            this.c3_200.Location = new System.Drawing.Point(750, 373);
            this.c3_200.Name = "c3_200";
            this.c3_200.Size = new System.Drawing.Size(219, 129);
            this.c3_200.TabIndex = 63;
            this.c3_200.Text = "$400";
            this.c3_200.UseVisualStyleBackColor = true;
            this.c3_200.Click += new System.EventHandler(this.c3_200_Click);
            // 
            // c2_200
            // 
            this.c2_200.Location = new System.Drawing.Point(422, 373);
            this.c2_200.Name = "c2_200";
            this.c2_200.Size = new System.Drawing.Size(219, 129);
            this.c2_200.TabIndex = 62;
            this.c2_200.Text = "$400";
            this.c2_200.UseVisualStyleBackColor = true;
            this.c2_200.Click += new System.EventHandler(this.c2_200_Click);
            // 
            // c1_200
            // 
            this.c1_200.Location = new System.Drawing.Point(95, 373);
            this.c1_200.Name = "c1_200";
            this.c1_200.Size = new System.Drawing.Size(219, 129);
            this.c1_200.TabIndex = 61;
            this.c1_200.Text = "$400";
            this.c1_200.UseVisualStyleBackColor = true;
            this.c1_200.Click += new System.EventHandler(this.c1_200_Click);
            // 
            // c2_100
            // 
            this.c2_100.Location = new System.Drawing.Point(422, 239);
            this.c2_100.Name = "c2_100";
            this.c2_100.Size = new System.Drawing.Size(219, 129);
            this.c2_100.TabIndex = 60;
            this.c2_100.Text = "$200";
            this.c2_100.UseVisualStyleBackColor = true;
            this.c2_100.Click += new System.EventHandler(this.c2_100_Click);
            // 
            // c6_100
            // 
            this.c6_100.Location = new System.Drawing.Point(1692, 239);
            this.c6_100.Name = "c6_100";
            this.c6_100.Size = new System.Drawing.Size(219, 129);
            this.c6_100.TabIndex = 59;
            this.c6_100.Text = "$200";
            this.c6_100.UseVisualStyleBackColor = true;
            // 
            // c5_100
            // 
            this.c5_100.Location = new System.Drawing.Point(1377, 239);
            this.c5_100.Name = "c5_100";
            this.c5_100.Size = new System.Drawing.Size(219, 129);
            this.c5_100.TabIndex = 58;
            this.c5_100.Text = "$200";
            this.c5_100.UseVisualStyleBackColor = true;
            // 
            // c4_100
            // 
            this.c4_100.Location = new System.Drawing.Point(1060, 239);
            this.c4_100.Name = "c4_100";
            this.c4_100.Size = new System.Drawing.Size(219, 129);
            this.c4_100.TabIndex = 57;
            this.c4_100.Text = "$200";
            this.c4_100.UseVisualStyleBackColor = true;
            // 
            // c3_100
            // 
            this.c3_100.Location = new System.Drawing.Point(750, 239);
            this.c3_100.Name = "c3_100";
            this.c3_100.Size = new System.Drawing.Size(219, 129);
            this.c3_100.TabIndex = 56;
            this.c3_100.Text = "$200";
            this.c3_100.UseVisualStyleBackColor = true;
            this.c3_100.Click += new System.EventHandler(this.c3_100_Click);
            // 
            // c1_100
            // 
            this.c1_100.Location = new System.Drawing.Point(95, 239);
            this.c1_100.Name = "c1_100";
            this.c1_100.Size = new System.Drawing.Size(219, 129);
            this.c1_100.TabIndex = 55;
            this.c1_100.Text = "$200";
            this.c1_100.UseVisualStyleBackColor = true;
            this.c1_100.Click += new System.EventHandler(this.c1_100_Click);
            // 
            // Exit
            // 
            this.Exit.BackColor = System.Drawing.Color.White;
            this.Exit.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Exit.BackgroundImage")));
            this.Exit.Location = new System.Drawing.Point(1678, 950);
            this.Exit.Name = "Exit";
            this.Exit.Size = new System.Drawing.Size(233, 34);
            this.Exit.TabIndex = 53;
            this.Exit.Text = "Exit";
            this.Exit.UseVisualStyleBackColor = false;
            this.Exit.Click += new System.EventHandler(this.Exit_Click);
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1924, 1026);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.numericUpDown3);
            this.Controls.Add(this.numericUpDown2);
            this.Controls.Add(this.numericUpDown1);
            this.Controls.Add(this.doubleJeopardy);
            this.Controls.Add(this.c6_500);
            this.Controls.Add(this.c5_500);
            this.Controls.Add(this.c4_500);
            this.Controls.Add(this.c3_500);
            this.Controls.Add(this.c2_500);
            this.Controls.Add(this.c1_500);
            this.Controls.Add(this.c6_400);
            this.Controls.Add(this.c5_400);
            this.Controls.Add(this.c4_400);
            this.Controls.Add(this.c3_400);
            this.Controls.Add(this.c2_400);
            this.Controls.Add(this.c1_400);
            this.Controls.Add(this.c6_300);
            this.Controls.Add(this.c5_300);
            this.Controls.Add(this.c4_300);
            this.Controls.Add(this.c3_300);
            this.Controls.Add(this.c2_300);
            this.Controls.Add(this.c1_300);
            this.Controls.Add(this.c6_200);
            this.Controls.Add(this.c5_200);
            this.Controls.Add(this.c4_200);
            this.Controls.Add(this.c3_200);
            this.Controls.Add(this.c2_200);
            this.Controls.Add(this.c1_200);
            this.Controls.Add(this.c2_100);
            this.Controls.Add(this.c6_100);
            this.Controls.Add(this.c5_100);
            this.Controls.Add(this.c4_100);
            this.Controls.Add(this.c3_100);
            this.Controls.Add(this.c1_100);
            this.Controls.Add(this.Exit);
            this.Name = "Form3";
            this.Text = "Form3";
            this.Load += new System.EventHandler(this.Form3_Load);
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.NumericUpDown numericUpDown3;
        private System.Windows.Forms.NumericUpDown numericUpDown2;
        private System.Windows.Forms.NumericUpDown numericUpDown1;
        private System.Windows.Forms.Button doubleJeopardy;
        private System.Windows.Forms.Button c6_500;
        private System.Windows.Forms.Button c5_500;
        private System.Windows.Forms.Button c4_500;
        private System.Windows.Forms.Button c3_500;
        private System.Windows.Forms.Button c2_500;
        private System.Windows.Forms.Button c1_500;
        private System.Windows.Forms.Button c6_400;
        private System.Windows.Forms.Button c5_400;
        private System.Windows.Forms.Button c4_400;
        private System.Windows.Forms.Button c3_400;
        private System.Windows.Forms.Button c2_400;
        private System.Windows.Forms.Button c1_400;
        private System.Windows.Forms.Button c6_300;
        private System.Windows.Forms.Button c5_300;
        private System.Windows.Forms.Button c4_300;
        private System.Windows.Forms.Button c3_300;
        private System.Windows.Forms.Button c2_300;
        private System.Windows.Forms.Button c1_300;
        private System.Windows.Forms.Button c6_200;
        private System.Windows.Forms.Button c5_200;
        private System.Windows.Forms.Button c4_200;
        private System.Windows.Forms.Button c3_200;
        private System.Windows.Forms.Button c2_200;
        private System.Windows.Forms.Button c1_200;
        private System.Windows.Forms.Button c2_100;
        private System.Windows.Forms.Button c6_100;
        private System.Windows.Forms.Button c5_100;
        private System.Windows.Forms.Button c4_100;
        private System.Windows.Forms.Button c3_100;
        private System.Windows.Forms.Button c1_100;
        private System.Windows.Forms.Button Exit;
    }
}