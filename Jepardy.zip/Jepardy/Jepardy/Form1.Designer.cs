﻿namespace Jepardy
{
    partial class Jeopardy
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Jeopardy));
            this.Exit = new System.Windows.Forms.Button();
            this.c1_100 = new System.Windows.Forms.Button();
            this.c3_100 = new System.Windows.Forms.Button();
            this.c4_100 = new System.Windows.Forms.Button();
            this.c5_100 = new System.Windows.Forms.Button();
            this.c6_100 = new System.Windows.Forms.Button();
            this.c2_100 = new System.Windows.Forms.Button();
            this.c1_200 = new System.Windows.Forms.Button();
            this.c2_200 = new System.Windows.Forms.Button();
            this.c3_200 = new System.Windows.Forms.Button();
            this.c4_200 = new System.Windows.Forms.Button();
            this.c5_200 = new System.Windows.Forms.Button();
            this.c6_200 = new System.Windows.Forms.Button();
            this.c1_300 = new System.Windows.Forms.Button();
            this.c2_300 = new System.Windows.Forms.Button();
            this.c3_300 = new System.Windows.Forms.Button();
            this.c4_300 = new System.Windows.Forms.Button();
            this.c5_300 = new System.Windows.Forms.Button();
            this.c6_300 = new System.Windows.Forms.Button();
            this.c1_400 = new System.Windows.Forms.Button();
            this.c2_400 = new System.Windows.Forms.Button();
            this.c3_400 = new System.Windows.Forms.Button();
            this.c4_400 = new System.Windows.Forms.Button();
            this.c5_400 = new System.Windows.Forms.Button();
            this.c6_400 = new System.Windows.Forms.Button();
            this.c1_500 = new System.Windows.Forms.Button();
            this.c2_500 = new System.Windows.Forms.Button();
            this.c3_500 = new System.Windows.Forms.Button();
            this.c4_500 = new System.Windows.Forms.Button();
            this.c5_500 = new System.Windows.Forms.Button();
            this.c6_500 = new System.Windows.Forms.Button();
            this.doubleJeopardy = new System.Windows.Forms.Button();
            this.numericUpDown1 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown2 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown3 = new System.Windows.Forms.NumericUpDown();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.testButton = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown3)).BeginInit();
            this.SuspendLayout();
            // 
            // Exit
            // 
            this.Exit.Location = new System.Drawing.Point(1679, 949);
            this.Exit.Name = "Exit";
            this.Exit.Size = new System.Drawing.Size(233, 34);
            this.Exit.TabIndex = 0;
            this.Exit.Text = "Exit";
            this.Exit.UseVisualStyleBackColor = true;
            this.Exit.Click += new System.EventHandler(this.Exit_Click);
            // 
            // c1_100
            // 
            this.c1_100.Location = new System.Drawing.Point(96, 238);
            this.c1_100.Name = "c1_100";
            this.c1_100.Size = new System.Drawing.Size(219, 129);
            this.c1_100.TabIndex = 9;
            this.c1_100.Text = "$100";
            this.c1_100.UseVisualStyleBackColor = true;
            this.c1_100.Click += new System.EventHandler(this.c1_100_Click);
            // 
            // c3_100
            // 
            this.c3_100.Location = new System.Drawing.Point(751, 238);
            this.c3_100.Name = "c3_100";
            this.c3_100.Size = new System.Drawing.Size(219, 129);
            this.c3_100.TabIndex = 10;
            this.c3_100.Text = "$100";
            this.c3_100.UseVisualStyleBackColor = true;
            this.c3_100.Click += new System.EventHandler(this.c3_100_Click);
            // 
            // c4_100
            // 
            this.c4_100.Location = new System.Drawing.Point(1061, 238);
            this.c4_100.Name = "c4_100";
            this.c4_100.Size = new System.Drawing.Size(219, 129);
            this.c4_100.TabIndex = 11;
            this.c4_100.Text = "$100";
            this.c4_100.UseVisualStyleBackColor = true;
            this.c4_100.Click += new System.EventHandler(this.c4_100_Click);
            // 
            // c5_100
            // 
            this.c5_100.Location = new System.Drawing.Point(1378, 238);
            this.c5_100.Name = "c5_100";
            this.c5_100.Size = new System.Drawing.Size(219, 129);
            this.c5_100.TabIndex = 12;
            this.c5_100.Text = "$100";
            this.c5_100.UseVisualStyleBackColor = true;
            this.c5_100.Click += new System.EventHandler(this.c5_100_Click);
            // 
            // c6_100
            // 
            this.c6_100.Location = new System.Drawing.Point(1693, 238);
            this.c6_100.Name = "c6_100";
            this.c6_100.Size = new System.Drawing.Size(219, 129);
            this.c6_100.TabIndex = 13;
            this.c6_100.Text = "$100";
            this.c6_100.UseVisualStyleBackColor = true;
            this.c6_100.Click += new System.EventHandler(this.c6_100_Click);
            // 
            // c2_100
            // 
            this.c2_100.Location = new System.Drawing.Point(423, 238);
            this.c2_100.Name = "c2_100";
            this.c2_100.Size = new System.Drawing.Size(219, 129);
            this.c2_100.TabIndex = 14;
            this.c2_100.Text = "$100";
            this.c2_100.UseVisualStyleBackColor = true;
            this.c2_100.Click += new System.EventHandler(this.c2_100_Click);
            // 
            // c1_200
            // 
            this.c1_200.Location = new System.Drawing.Point(96, 372);
            this.c1_200.Name = "c1_200";
            this.c1_200.Size = new System.Drawing.Size(219, 129);
            this.c1_200.TabIndex = 15;
            this.c1_200.Text = "$200";
            this.c1_200.UseVisualStyleBackColor = true;
            this.c1_200.Click += new System.EventHandler(this.c1_200_Click);
            // 
            // c2_200
            // 
            this.c2_200.Location = new System.Drawing.Point(423, 372);
            this.c2_200.Name = "c2_200";
            this.c2_200.Size = new System.Drawing.Size(219, 129);
            this.c2_200.TabIndex = 16;
            this.c2_200.Text = "$200";
            this.c2_200.UseVisualStyleBackColor = true;
            this.c2_200.Click += new System.EventHandler(this.c2_200_Click);
            // 
            // c3_200
            // 
            this.c3_200.Location = new System.Drawing.Point(751, 372);
            this.c3_200.Name = "c3_200";
            this.c3_200.Size = new System.Drawing.Size(219, 129);
            this.c3_200.TabIndex = 17;
            this.c3_200.Text = "$200";
            this.c3_200.UseVisualStyleBackColor = true;
            this.c3_200.Click += new System.EventHandler(this.c3_200_Click);
            // 
            // c4_200
            // 
            this.c4_200.Location = new System.Drawing.Point(1061, 372);
            this.c4_200.Name = "c4_200";
            this.c4_200.Size = new System.Drawing.Size(219, 129);
            this.c4_200.TabIndex = 18;
            this.c4_200.Text = "$200";
            this.c4_200.UseVisualStyleBackColor = true;
            this.c4_200.Click += new System.EventHandler(this.c4_200_Click);
            // 
            // c5_200
            // 
            this.c5_200.Location = new System.Drawing.Point(1378, 372);
            this.c5_200.Name = "c5_200";
            this.c5_200.Size = new System.Drawing.Size(219, 129);
            this.c5_200.TabIndex = 19;
            this.c5_200.Text = "$200";
            this.c5_200.UseVisualStyleBackColor = true;
            this.c5_200.Click += new System.EventHandler(this.c5_200_Click);
            // 
            // c6_200
            // 
            this.c6_200.Location = new System.Drawing.Point(1693, 372);
            this.c6_200.Name = "c6_200";
            this.c6_200.Size = new System.Drawing.Size(219, 129);
            this.c6_200.TabIndex = 20;
            this.c6_200.Text = "$200";
            this.c6_200.UseVisualStyleBackColor = true;
            this.c6_200.Click += new System.EventHandler(this.c6_200_Click);
            // 
            // c1_300
            // 
            this.c1_300.Location = new System.Drawing.Point(96, 507);
            this.c1_300.Name = "c1_300";
            this.c1_300.Size = new System.Drawing.Size(219, 129);
            this.c1_300.TabIndex = 21;
            this.c1_300.Text = "$300";
            this.c1_300.UseVisualStyleBackColor = true;
            this.c1_300.Click += new System.EventHandler(this.c1_300_Click);
            // 
            // c2_300
            // 
            this.c2_300.Location = new System.Drawing.Point(423, 507);
            this.c2_300.Name = "c2_300";
            this.c2_300.Size = new System.Drawing.Size(219, 129);
            this.c2_300.TabIndex = 22;
            this.c2_300.Text = "$300";
            this.c2_300.UseVisualStyleBackColor = true;
            this.c2_300.Click += new System.EventHandler(this.c2_300_Click);
            // 
            // c3_300
            // 
            this.c3_300.Location = new System.Drawing.Point(751, 507);
            this.c3_300.Name = "c3_300";
            this.c3_300.Size = new System.Drawing.Size(219, 129);
            this.c3_300.TabIndex = 23;
            this.c3_300.Text = "$300";
            this.c3_300.UseVisualStyleBackColor = true;
            this.c3_300.Click += new System.EventHandler(this.c3_300_Click);
            // 
            // c4_300
            // 
            this.c4_300.Location = new System.Drawing.Point(1061, 507);
            this.c4_300.Name = "c4_300";
            this.c4_300.Size = new System.Drawing.Size(219, 129);
            this.c4_300.TabIndex = 24;
            this.c4_300.Text = "$300";
            this.c4_300.UseVisualStyleBackColor = true;
            this.c4_300.Click += new System.EventHandler(this.c4_300_Click);
            // 
            // c5_300
            // 
            this.c5_300.Location = new System.Drawing.Point(1378, 507);
            this.c5_300.Name = "c5_300";
            this.c5_300.Size = new System.Drawing.Size(219, 129);
            this.c5_300.TabIndex = 25;
            this.c5_300.Text = "$300";
            this.c5_300.UseVisualStyleBackColor = true;
            this.c5_300.Click += new System.EventHandler(this.c5_300_Click);
            // 
            // c6_300
            // 
            this.c6_300.Location = new System.Drawing.Point(1693, 507);
            this.c6_300.Name = "c6_300";
            this.c6_300.Size = new System.Drawing.Size(219, 129);
            this.c6_300.TabIndex = 26;
            this.c6_300.Text = "$300";
            this.c6_300.UseVisualStyleBackColor = true;
            this.c6_300.Click += new System.EventHandler(this.c6_300_Click);
            // 
            // c1_400
            // 
            this.c1_400.Location = new System.Drawing.Point(96, 642);
            this.c1_400.Name = "c1_400";
            this.c1_400.Size = new System.Drawing.Size(219, 129);
            this.c1_400.TabIndex = 27;
            this.c1_400.Text = "$400";
            this.c1_400.UseVisualStyleBackColor = true;
            this.c1_400.Click += new System.EventHandler(this.c1_400_Click);
            // 
            // c2_400
            // 
            this.c2_400.Location = new System.Drawing.Point(423, 642);
            this.c2_400.Name = "c2_400";
            this.c2_400.Size = new System.Drawing.Size(219, 129);
            this.c2_400.TabIndex = 28;
            this.c2_400.Text = "$400";
            this.c2_400.UseVisualStyleBackColor = true;
            this.c2_400.Click += new System.EventHandler(this.c2_400_Click);
            // 
            // c3_400
            // 
            this.c3_400.Location = new System.Drawing.Point(751, 642);
            this.c3_400.Name = "c3_400";
            this.c3_400.Size = new System.Drawing.Size(219, 129);
            this.c3_400.TabIndex = 29;
            this.c3_400.Text = "$400";
            this.c3_400.UseVisualStyleBackColor = true;
            this.c3_400.Click += new System.EventHandler(this.c3_400_Click);
            // 
            // c4_400
            // 
            this.c4_400.Location = new System.Drawing.Point(1061, 642);
            this.c4_400.Name = "c4_400";
            this.c4_400.Size = new System.Drawing.Size(219, 129);
            this.c4_400.TabIndex = 30;
            this.c4_400.Text = "$400";
            this.c4_400.UseVisualStyleBackColor = true;
            this.c4_400.Click += new System.EventHandler(this.c4_400_Click);
            // 
            // c5_400
            // 
            this.c5_400.Location = new System.Drawing.Point(1378, 642);
            this.c5_400.Name = "c5_400";
            this.c5_400.Size = new System.Drawing.Size(219, 129);
            this.c5_400.TabIndex = 31;
            this.c5_400.Text = "$400";
            this.c5_400.UseVisualStyleBackColor = true;
            this.c5_400.Click += new System.EventHandler(this.c5_400_Click);
            // 
            // c6_400
            // 
            this.c6_400.Location = new System.Drawing.Point(1693, 642);
            this.c6_400.Name = "c6_400";
            this.c6_400.Size = new System.Drawing.Size(219, 129);
            this.c6_400.TabIndex = 32;
            this.c6_400.Text = "$400";
            this.c6_400.UseVisualStyleBackColor = true;
            this.c6_400.Click += new System.EventHandler(this.c6_400_Click);
            // 
            // c1_500
            // 
            this.c1_500.Location = new System.Drawing.Point(96, 777);
            this.c1_500.Name = "c1_500";
            this.c1_500.Size = new System.Drawing.Size(219, 129);
            this.c1_500.TabIndex = 33;
            this.c1_500.Text = "$500";
            this.c1_500.UseVisualStyleBackColor = true;
            this.c1_500.Click += new System.EventHandler(this.c1_500_Click);
            // 
            // c2_500
            // 
            this.c2_500.Location = new System.Drawing.Point(423, 777);
            this.c2_500.Name = "c2_500";
            this.c2_500.Size = new System.Drawing.Size(219, 129);
            this.c2_500.TabIndex = 35;
            this.c2_500.Text = "$500";
            this.c2_500.UseVisualStyleBackColor = true;
            this.c2_500.Click += new System.EventHandler(this.c2_500_Click);
            // 
            // c3_500
            // 
            this.c3_500.Location = new System.Drawing.Point(751, 777);
            this.c3_500.Name = "c3_500";
            this.c3_500.Size = new System.Drawing.Size(219, 129);
            this.c3_500.TabIndex = 35;
            this.c3_500.Text = "$500";
            this.c3_500.UseVisualStyleBackColor = true;
            this.c3_500.Click += new System.EventHandler(this.c3_500_Click);
            // 
            // c4_500
            // 
            this.c4_500.Location = new System.Drawing.Point(1061, 777);
            this.c4_500.Name = "c4_500";
            this.c4_500.Size = new System.Drawing.Size(219, 129);
            this.c4_500.TabIndex = 36;
            this.c4_500.Text = "$500";
            this.c4_500.UseVisualStyleBackColor = true;
            this.c4_500.Click += new System.EventHandler(this.c4_500_Click);
            // 
            // c5_500
            // 
            this.c5_500.Location = new System.Drawing.Point(1378, 777);
            this.c5_500.Name = "c5_500";
            this.c5_500.Size = new System.Drawing.Size(219, 129);
            this.c5_500.TabIndex = 37;
            this.c5_500.Text = "$500";
            this.c5_500.UseVisualStyleBackColor = true;
            this.c5_500.Click += new System.EventHandler(this.c5_500_Click);
            // 
            // c6_500
            // 
            this.c6_500.Location = new System.Drawing.Point(1693, 777);
            this.c6_500.Name = "c6_500";
            this.c6_500.Size = new System.Drawing.Size(219, 129);
            this.c6_500.TabIndex = 38;
            this.c6_500.Text = "$500";
            this.c6_500.UseVisualStyleBackColor = true;
            this.c6_500.Click += new System.EventHandler(this.c6_500_Click);
            // 
            // doubleJeopardy
            // 
            this.doubleJeopardy.Location = new System.Drawing.Point(256, 25);
            this.doubleJeopardy.Name = "doubleJeopardy";
            this.doubleJeopardy.Size = new System.Drawing.Size(107, 43);
            this.doubleJeopardy.TabIndex = 39;
            this.doubleJeopardy.Text = "Double Jeopardy!";
            this.doubleJeopardy.UseVisualStyleBackColor = true;
            this.doubleJeopardy.Click += new System.EventHandler(this.doubleJeopardy_Click);
            // 
            // numericUpDown1
            // 
            this.numericUpDown1.Increment = new decimal(new int[] {
            100,
            0,
            0,
            0});
            this.numericUpDown1.Location = new System.Drawing.Point(143, 961);
            this.numericUpDown1.Maximum = new decimal(new int[] {
            1316134912,
            2328,
            0,
            0});
            this.numericUpDown1.Minimum = new decimal(new int[] {
            -727379968,
            232,
            0,
            -2147483648});
            this.numericUpDown1.Name = "numericUpDown1";
            this.numericUpDown1.Size = new System.Drawing.Size(172, 22);
            this.numericUpDown1.TabIndex = 40;
            // 
            // numericUpDown2
            // 
            this.numericUpDown2.Increment = new decimal(new int[] {
            100,
            0,
            0,
            0});
            this.numericUpDown2.Location = new System.Drawing.Point(688, 961);
            this.numericUpDown2.Maximum = new decimal(new int[] {
            -1486618624,
            232830643,
            0,
            0});
            this.numericUpDown2.Minimum = new decimal(new int[] {
            1316134912,
            2328,
            0,
            -2147483648});
            this.numericUpDown2.Name = "numericUpDown2";
            this.numericUpDown2.Size = new System.Drawing.Size(172, 22);
            this.numericUpDown2.TabIndex = 41;
            // 
            // numericUpDown3
            // 
            this.numericUpDown3.Increment = new decimal(new int[] {
            100,
            0,
            0,
            0});
            this.numericUpDown3.Location = new System.Drawing.Point(1219, 961);
            this.numericUpDown3.Maximum = new decimal(new int[] {
            1569325056,
            23283064,
            0,
            0});
            this.numericUpDown3.Minimum = new decimal(new int[] {
            1215752192,
            23,
            0,
            -2147483648});
            this.numericUpDown3.Name = "numericUpDown3";
            this.numericUpDown3.Size = new System.Drawing.Size(172, 22);
            this.numericUpDown3.TabIndex = 42;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label1.Location = new System.Drawing.Point(198, 922);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(56, 17);
            this.label1.TabIndex = 43;
            this.label1.Text = "Team 1";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label2.Location = new System.Drawing.Point(736, 922);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(56, 17);
            this.label2.TabIndex = 44;
            this.label2.Text = "Team 2";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label3.Location = new System.Drawing.Point(1269, 922);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(56, 17);
            this.label3.TabIndex = 45;
            this.label3.Text = "Team 3";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F);
            this.label4.ForeColor = System.Drawing.Color.Yellow;
            this.label4.Location = new System.Drawing.Point(128, 182);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(139, 28);
            this.label4.TabIndex = 46;
            this.label4.Text = "Category 1";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F);
            this.label5.ForeColor = System.Drawing.Color.Yellow;
            this.label5.Location = new System.Drawing.Point(454, 182);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(139, 28);
            this.label5.TabIndex = 47;
            this.label5.Text = "Category 2";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F);
            this.label6.ForeColor = System.Drawing.Color.Yellow;
            this.label6.Location = new System.Drawing.Point(772, 182);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(139, 28);
            this.label6.TabIndex = 48;
            this.label6.Text = "Category 3";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F);
            this.label7.ForeColor = System.Drawing.Color.Yellow;
            this.label7.Location = new System.Drawing.Point(1106, 182);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(139, 28);
            this.label7.TabIndex = 49;
            this.label7.Text = "Category 4";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F);
            this.label8.ForeColor = System.Drawing.Color.Yellow;
            this.label8.Location = new System.Drawing.Point(1411, 182);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(139, 28);
            this.label8.TabIndex = 50;
            this.label8.Text = "Category 5";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F);
            this.label9.ForeColor = System.Drawing.Color.Yellow;
            this.label9.Location = new System.Drawing.Point(1731, 182);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(139, 28);
            this.label9.TabIndex = 51;
            this.label9.Text = "Category 6";
            // 
            // testButton
            // 
            this.testButton.Location = new System.Drawing.Point(0, 0);
            this.testButton.Name = "testButton";
            this.testButton.Size = new System.Drawing.Size(75, 23);
            this.testButton.TabIndex = 52;
            this.testButton.Text = "Test";
            this.testButton.UseVisualStyleBackColor = true;
            this.testButton.Visible = false;
            this.testButton.Click += new System.EventHandler(this.testButton_Click);
            // 
            // Jeopardy
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Blue;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1924, 1003);
            this.Controls.Add(this.testButton);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.numericUpDown3);
            this.Controls.Add(this.numericUpDown2);
            this.Controls.Add(this.numericUpDown1);
            this.Controls.Add(this.doubleJeopardy);
            this.Controls.Add(this.c6_500);
            this.Controls.Add(this.c5_500);
            this.Controls.Add(this.c4_500);
            this.Controls.Add(this.c3_500);
            this.Controls.Add(this.c2_500);
            this.Controls.Add(this.c1_500);
            this.Controls.Add(this.c6_400);
            this.Controls.Add(this.c5_400);
            this.Controls.Add(this.c4_400);
            this.Controls.Add(this.c3_400);
            this.Controls.Add(this.c2_400);
            this.Controls.Add(this.c1_400);
            this.Controls.Add(this.c6_300);
            this.Controls.Add(this.c5_300);
            this.Controls.Add(this.c4_300);
            this.Controls.Add(this.c3_300);
            this.Controls.Add(this.c2_300);
            this.Controls.Add(this.c1_300);
            this.Controls.Add(this.c6_200);
            this.Controls.Add(this.c5_200);
            this.Controls.Add(this.c4_200);
            this.Controls.Add(this.c3_200);
            this.Controls.Add(this.c2_200);
            this.Controls.Add(this.c1_200);
            this.Controls.Add(this.c2_100);
            this.Controls.Add(this.c6_100);
            this.Controls.Add(this.c5_100);
            this.Controls.Add(this.c4_100);
            this.Controls.Add(this.c3_100);
            this.Controls.Add(this.c1_100);
            this.Controls.Add(this.Exit);
            this.DoubleBuffered = true;
            this.Name = "Jeopardy";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown3)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button Exit;
        private System.Windows.Forms.Button c1_100;
        private System.Windows.Forms.Button c3_100;
        private System.Windows.Forms.Button c4_100;
        private System.Windows.Forms.Button c5_100;
        private System.Windows.Forms.Button c6_100;
        private System.Windows.Forms.Button c2_100;
        private System.Windows.Forms.Button c1_200;
        private System.Windows.Forms.Button c2_200;
        private System.Windows.Forms.Button c3_200;
        private System.Windows.Forms.Button c4_200;
        private System.Windows.Forms.Button c5_200;
        private System.Windows.Forms.Button c6_200;
        private System.Windows.Forms.Button c1_300;
        private System.Windows.Forms.Button c2_300;
        private System.Windows.Forms.Button c3_300;
        private System.Windows.Forms.Button c4_300;
        private System.Windows.Forms.Button c5_300;
        private System.Windows.Forms.Button c6_300;
        private System.Windows.Forms.Button c1_400;
        private System.Windows.Forms.Button c2_400;
        private System.Windows.Forms.Button c3_400;
        private System.Windows.Forms.Button c4_400;
        private System.Windows.Forms.Button c5_400;
        private System.Windows.Forms.Button c6_400;
        private System.Windows.Forms.Button c1_500;
        private System.Windows.Forms.Button c2_500;
        private System.Windows.Forms.Button c3_500;
        private System.Windows.Forms.Button c4_500;
        private System.Windows.Forms.Button c5_500;
        private System.Windows.Forms.Button c6_500;
        private System.Windows.Forms.Button doubleJeopardy;
        private System.Windows.Forms.NumericUpDown numericUpDown1;
        private System.Windows.Forms.NumericUpDown numericUpDown2;
        private System.Windows.Forms.NumericUpDown numericUpDown3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button testButton;
    }
}

