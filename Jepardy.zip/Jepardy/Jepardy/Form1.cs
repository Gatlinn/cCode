﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Jepardy
{
    public partial class Jeopardy : Form
    {
        public Jeopardy()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            FormBorderStyle = FormBorderStyle.None;
            WindowState = FormWindowState.Maximized;
        }

        private void Exit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void c1_100_Click(object sender, EventArgs e)
        {
            c1_100.Enabled = false;
            var frm1 = new column1_100();
            frm1.Show();
        }

        private void c1_200_Click(object sender, EventArgs e)
        {
            c1_200.Enabled = false;
            var frm2 = new Form2();
            frm2.Show();
        }

        private void c1_300_Click(object sender, EventArgs e)
        {
            c1_300.Enabled = false;
            var frm3_1 = new column1_300();
            frm3_1.Show();
        }

        private void c1_400_Click(object sender, EventArgs e)
        {
            c1_400.Enabled = false;
            var frm1_4 = new c1_400();
            frm1_4.Show();
        }

        private void c1_500_Click(object sender, EventArgs e)
        {
            c1_500.Enabled = false;
            var frm1_5 = new c1_500();
            frm1_5.Show();
        }

        private void c2_100_Click(object sender, EventArgs e)
        {
            c2_100.Enabled = false;
            var f2_1 = new c2_100();
            f2_1.Show();
        }

        private void c2_200_Click(object sender, EventArgs e)
        {
            c2_200.Enabled = false;
            var f2_2 = new c2_200();
            f2_2.Show();
        }

        private void c2_300_Click(object sender, EventArgs e)
        {
            c2_300.Enabled = false;
            var f2_3 = new c2_300();
            f2_3.Show();
        }

        private void c2_400_Click(object sender, EventArgs e)
        {
            c2_400.Enabled = false;
            var f2_4 = new c2_400();
            f2_4.Show();
        }

        private void c2_500_Click(object sender, EventArgs e)
        {
            c2_500.Enabled = false;
            var f2_5 = new cs2_500();
            f2_5.Show();
        }

        private void c3_100_Click(object sender, EventArgs e)
        {
            c3_100.Enabled = false;
            var f3_1 = new c3_100();
            f3_1.Show();
        }

        private void c3_200_Click(object sender, EventArgs e)
        {
            c3_200.Enabled = false;
            var f3_2 = new c3_200();
            f3_2.Show();
        }

        private void c3_300_Click(object sender, EventArgs e)
        {
            c3_300.Enabled = false;
            var f3_3 = new c3_300();
            f3_3.Show();
        }

        private void c3_400_Click(object sender, EventArgs e)
        {
            c3_400.Enabled = false;
            var f3_4 = new c3_400();
            f3_4.Show();
        }

        private void c3_500_Click(object sender, EventArgs e)
        {
            c3_500.Enabled = false;
            var f3_5 = new c3_500();
            f3_5.Show();
        }

        private void c4_100_Click(object sender, EventArgs e)
        {
            c4_100.Enabled = false;
            var f4_1 = new c4_100();
            f4_1.Show();
        }

        private void c4_200_Click(object sender, EventArgs e)
        {
            c4_200.Enabled = false;
            var f4_2 = new c4_200();
            f4_2.Show();
        }

        private void c4_300_Click(object sender, EventArgs e)
        {
            c4_300.Enabled = false;
            var f4_3 = new c4_300();
            f4_3.Show();
        }

        private void c4_400_Click(object sender, EventArgs e)
        {
            c4_400.Enabled = false;
            var f4_4 = new c4_400();
            f4_4.Show();
        }

        private void c4_500_Click(object sender, EventArgs e)
        {
            c4_500.Enabled = false;
            var f4_5 = new c4_500();
            f4_5.Show();
        }

        private void c5_100_Click(object sender, EventArgs e)
        {
            c5_100.Enabled = false;
            var f5_1 = new c5_100();
            f5_1.Show();
        }

        private void c5_200_Click(object sender, EventArgs e)
        {
            c5_200.Enabled = false;
            var f5_2 = new c5_200();
            f5_2.Show();
        }

        private void c5_300_Click(object sender, EventArgs e)
        {
            c5_300.Enabled = false;
            var f5_3 = new c5_300();
            f5_3.Show();
        }

        private void c5_400_Click(object sender, EventArgs e)
        {
            c5_400.Enabled = false;
            var f5_4 = new c5_400();
            f5_4.Show();
        }

        private void c5_500_Click(object sender, EventArgs e)
        {
            c5_500.Enabled = false;
            var f5_5 = new c5_500();
            f5_5.Show();
        }

        private void c6_100_Click(object sender, EventArgs e)
        {
            c6_100.Enabled = false;
            var f6_1 = new c6_100();
            f6_1.Show();
        }

        private void c6_200_Click(object sender, EventArgs e)
        {
            c6_200.Enabled = false;
            var f6_2 = new c6_200();
            f6_2.Show();
        }

        private void c6_300_Click(object sender, EventArgs e)
        {
            c6_300.Enabled = false;
            var f6_3 = new c6_300();
            f6_3.Show();
        }

        private void c6_400_Click(object sender, EventArgs e)
        {
            c6_400.Enabled = false;
            var f6_4 = new f6_400();
            f6_4.Show();
        }

        private void c6_500_Click(object sender, EventArgs e)
        {
            var f6_5 = new c6_500();
            f6_5.Show();
            c6_500.Enabled = false;
        }

        private void testButton_Click(object sender, EventArgs e)
        {
            var frm = new test();
            frm.Show();
        }

        private void doubleJeopardy_Click(object sender, EventArgs e)
        {
            var doubeJeopardy = new Form3();
            doubeJeopardy.Show();
        }
    }
}
