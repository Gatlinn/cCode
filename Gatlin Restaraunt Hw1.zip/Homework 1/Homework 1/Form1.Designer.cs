﻿namespace Homework_1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.label1 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.todaysSoup = new System.Windows.Forms.PictureBox();
            this.chefSecial = new System.Windows.Forms.PictureBox();
            this.krabbyPatty = new System.Windows.Forms.PictureBox();
            this.soupPrice = new System.Windows.Forms.Label();
            this.specialPrice = new System.Windows.Forms.Label();
            this.burgerPrice = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.todaysSoup)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chefSecial)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.krabbyPatty)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Forte", 19.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(186, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(268, 36);
            this.label1.TabIndex = 0;
            this.label1.Text = "Food For Friends";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(65, 68);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(159, 56);
            this.button1.TabIndex = 1;
            this.button1.Text = "Today\'s Soup";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(65, 553);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(159, 56);
            this.button2.TabIndex = 2;
            this.button2.Text = "Burger of the Week";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(65, 297);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(159, 56);
            this.button3.TabIndex = 3;
            this.button3.Text = "Chef\'s Special";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(537, 0);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(101, 45);
            this.button4.TabIndex = 4;
            this.button4.Text = "Exit";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // todaysSoup
            // 
            this.todaysSoup.Image = ((System.Drawing.Image)(resources.GetObject("todaysSoup.Image")));
            this.todaysSoup.Location = new System.Drawing.Point(329, 59);
            this.todaysSoup.Name = "todaysSoup";
            this.todaysSoup.Size = new System.Drawing.Size(170, 159);
            this.todaysSoup.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.todaysSoup.TabIndex = 5;
            this.todaysSoup.TabStop = false;
            this.todaysSoup.Visible = false;
            this.todaysSoup.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // chefSecial
            // 
            this.chefSecial.Cursor = System.Windows.Forms.Cursors.Default;
            this.chefSecial.Image = ((System.Drawing.Image)(resources.GetObject("chefSecial.Image")));
            this.chefSecial.Location = new System.Drawing.Point(279, 261);
            this.chefSecial.Name = "chefSecial";
            this.chefSecial.Size = new System.Drawing.Size(280, 214);
            this.chefSecial.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.chefSecial.TabIndex = 6;
            this.chefSecial.TabStop = false;
            this.chefSecial.Visible = false;
            this.chefSecial.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // krabbyPatty
            // 
            this.krabbyPatty.Image = ((System.Drawing.Image)(resources.GetObject("krabbyPatty.Image")));
            this.krabbyPatty.Location = new System.Drawing.Point(316, 530);
            this.krabbyPatty.Name = "krabbyPatty";
            this.krabbyPatty.Size = new System.Drawing.Size(200, 180);
            this.krabbyPatty.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.krabbyPatty.TabIndex = 7;
            this.krabbyPatty.TabStop = false;
            this.krabbyPatty.Visible = false;
            this.krabbyPatty.Click += new System.EventHandler(this.pictureBox3_Click);
            // 
            // soupPrice
            // 
            this.soupPrice.AutoSize = true;
            this.soupPrice.BackColor = System.Drawing.SystemColors.ControlDark;
            this.soupPrice.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.soupPrice.Font = new System.Drawing.Font("Stencil", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.soupPrice.Location = new System.Drawing.Point(42, 127);
            this.soupPrice.Name = "soupPrice";
            this.soupPrice.Size = new System.Drawing.Size(212, 60);
            this.soupPrice.TabIndex = 8;
            this.soupPrice.Text = "Soup of the Day\r\n $3.25";
            this.soupPrice.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.soupPrice.Visible = false;
            this.soupPrice.Click += new System.EventHandler(this.soupPrice_Click);
            // 
            // specialPrice
            // 
            this.specialPrice.AutoSize = true;
            this.specialPrice.BackColor = System.Drawing.SystemColors.ControlDark;
            this.specialPrice.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.specialPrice.Font = new System.Drawing.Font("Stencil", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.specialPrice.Location = new System.Drawing.Point(51, 356);
            this.specialPrice.Name = "specialPrice";
            this.specialPrice.Size = new System.Drawing.Size(193, 60);
            this.specialPrice.TabIndex = 9;
            this.specialPrice.Text = "Chef\'s Special\r\n$10.15";
            this.specialPrice.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.specialPrice.Visible = false;
            this.specialPrice.Click += new System.EventHandler(this.specialPrice_Click);
            // 
            // burgerPrice
            // 
            this.burgerPrice.AutoSize = true;
            this.burgerPrice.BackColor = System.Drawing.SystemColors.ControlDark;
            this.burgerPrice.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.burgerPrice.Font = new System.Drawing.Font("Stencil", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.burgerPrice.Location = new System.Drawing.Point(22, 612);
            this.burgerPrice.Name = "burgerPrice";
            this.burgerPrice.Size = new System.Drawing.Size(269, 60);
            this.burgerPrice.TabIndex = 10;
            this.burgerPrice.Text = "Burger of the Week\r\n$8.39";
            this.burgerPrice.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.burgerPrice.Visible = false;
            this.burgerPrice.Click += new System.EventHandler(this.burgerPrice_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Tomato;
            this.ClientSize = new System.Drawing.Size(638, 722);
            this.Controls.Add(this.burgerPrice);
            this.Controls.Add(this.specialPrice);
            this.Controls.Add(this.soupPrice);
            this.Controls.Add(this.krabbyPatty);
            this.Controls.Add(this.chefSecial);
            this.Controls.Add(this.todaysSoup);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Food For You";
            ((System.ComponentModel.ISupportInitialize)(this.todaysSoup)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chefSecial)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.krabbyPatty)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.PictureBox todaysSoup;
        private System.Windows.Forms.PictureBox chefSecial;
        private System.Windows.Forms.PictureBox krabbyPatty;
        private System.Windows.Forms.Label soupPrice;
        private System.Windows.Forms.Label specialPrice;
        private System.Windows.Forms.Label burgerPrice;
    }
}

