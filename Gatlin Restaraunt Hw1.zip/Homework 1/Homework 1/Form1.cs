﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Homework_1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            todaysSoup.Visible = true;
            soupPrice.Visible = true;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            chefSecial.Visible = true;
            specialPrice.Visible = true;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            krabbyPatty.Visible = true;
            burgerPrice.Visible = true;

        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void soupPrice_Click(object sender, EventArgs e)
        {

        }

        private void specialPrice_Click(object sender, EventArgs e)
        {

        }

        private void burgerPrice_Click(object sender, EventArgs e)
        {
           
        }
    }
}
